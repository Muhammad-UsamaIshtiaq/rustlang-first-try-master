//! # Language infos
#[derive(Debug)]
pub enum Language {
    English,
    French,
}
